#include "collisions.h"
#include <iostream>

bool CheckCollision_sphere(
    const glm::vec3& spherePos,
    float sphereRadius,
    const std::vector<BunnySphere>& bunnySpheres,
    int index
) {

    const BunnySphere& sphere = bunnySpheres[index];
    float distancia_x = spherePos.x - sphere.position.x;
    float distancia_y = spherePos.y - sphere.position.y;
    float distancia_z = spherePos.z - sphere.position.z;
    float distSquared = distancia_x * distancia_x + distancia_y * distancia_y + distancia_z * distancia_z;
    float soma_dos_raio = sphereRadius + sphere.raio;

    return distSquared <= soma_dos_raio * soma_dos_raio;
}

bool CheckCollision_sphere_cylinder(const glm::vec3& spherePos, float sphereRadius, const DogCylinder& cylinder) {
    float distancia_x = spherePos.x - cylinder.position.x;
    float distancia_z = spherePos.z - cylinder.position.z;
    float distancia_hor_sq = distancia_x * distancia_x + distancia_z * distancia_z;


    float soma_dos_raio= sphereRadius + cylinder.raio;

    if (distancia_hor_sq > soma_dos_raio * soma_dos_raio) {
        return false;
    }


    float sphere_baixo = spherePos.y - sphereRadius;
    float sphere_topo = spherePos.y + sphereRadius;
    float cilindro_baixo = cylinder.position.y;
    float cilindro_topo = cylinder.position.y + cylinder.altura;


    if (sphere_topo < cilindro_baixo || sphere_baixo > cilindro_topo) {
        return false;
    }

    return true;
}
void UpdateBunnySpheres(std::vector<BunnySphere>& bunnySpheres,
                       const std::vector<glm::vec3>& bunnyPositions) {
    for (int i = 0; i < bunnySpheres.size(); ++i) {
        if (i < bunnyPositions.size()) {
            bunnySpheres[i].position = bunnyPositions[i];
        }
    }
}
