#include <glm/vec3.hpp>
#include <vector>

struct BunnySphere {
    glm::vec3 position;
    float raio;
    bool colisao;
};


struct DogCylinder {
    glm::vec3 position;
    float raio;
    float altura;
};

bool CheckCollision_sphere(const glm::vec3& spherePos, float sphereRadius,
                   const std::vector<BunnySphere>& bunnySpheres, int index);
void UpdateBunnySpheres(std::vector<BunnySphere>& bunnySpheres,
                       const std::vector<glm::vec3>& bunnyPositions);

bool CheckCollision_sphere_cylinder(const glm::vec3& spherePos, float sphereRadius, const DogCylinder& cylinder);
